import java.util.Scanner;

class cal {
	int a,b,c;
	
	public void addition()
	{
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b : ");
		b=sc.nextInt();
		System.out.println(a+b);
		
	}
	public void subtraction()
	{
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b: ");
		b=sc.nextInt();
		System.out.println(a-b);
	}
	public void multiplication()
	{
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b: ");
		b=sc.nextInt();
		System.out.println(a*b);
		
	}
	public void division()
	{
		System.out.println("Enter a: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		System.out.println("Enter b: ");
		b=sc.nextInt();
		try {
			System.out.println(a/b);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}	
		
	}
}



public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		cal a1=new cal();
		
		
		
		System.out.println("Select add or sub or mul or div");
		String c;
		Scanner sc=new Scanner(System.in);
		c=sc.next();
		switch(c) {
		case "add":
			a1.addition();
			break;
		case "sub":
			a1.subtraction();
			break;
		case "mul":
			a1.multiplication();
			break;
		case "div":
			a1.division();
			break;
			
		}
	}

}

