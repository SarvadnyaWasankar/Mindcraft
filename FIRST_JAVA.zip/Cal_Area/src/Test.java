 class Shape{
	 public void area(int l, int w) {
		 int l1,w1;
		 l1=l;
		 w1=w;
		 System.out.println("area of rectangle "+l*w);
	 }
	 public void area(int l) {
		 int l1;
		 l1=l;
		 System.out.println("area of square "+l*l);
	 }
	 public void area(float r) {
		 double pi=3.14,r1;
		 r1=r;
		 System.out.println("area of circle "+ pi*r*r);
	 }
 }
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Shape s1=new Shape();
		s1.area(10, 5);
		s1.area(8);
		s1.area(5.5f);

	}

}
