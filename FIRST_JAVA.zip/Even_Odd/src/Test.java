import java.util.Scanner;

class evenodd{
	int a;
	public void function() {
		System.out.print("Enter number: ");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		if(a%2==0)
			System.out.println("even");
		else
			System.out.println("odd");
	}

}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		evenodd a1=new evenodd();
		a1.function();
		

	}

}
