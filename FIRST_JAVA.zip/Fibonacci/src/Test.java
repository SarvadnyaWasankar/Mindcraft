class fib{
	int a=0,b=1,n=10;
	public void function()
	{
		System.out.println("FibSeries= "+n); 
		for(int i=0; i<n;i++)
		{
			System.out.print(a+",");
			
			int c=a+b;
			a=b;
			b=c;
		}
		
	}
	
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		fib a1=new fib();
		a1.function();

	}

}
