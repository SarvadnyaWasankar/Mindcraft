import java.util.Scanner;
class largest
{
	int a,b,c,temp;
	public  void func()
	{
		System.out.println("Enter 1st no: ");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		System.out.println("Enter 2nd no: ");
		int b=sc.nextInt();
		System.out.println("Enter 3rd no: ");
		int c=sc.nextInt();
		int temp=a;
		if(b>temp)
		{
			temp=b;
		}
		if(c>temp)
		{
			temp=c;
		}
		System.out.println("Largest No: " + temp);
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		largest a1=new largest();
		a1.func();

	}

}
