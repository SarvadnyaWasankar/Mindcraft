class Add {
	int a,b,c;
	
	public void Addition() {
		a=10;
		b=5;
		c=a+b;
	    System.out.println(c);
	}
	
	public void Addition(int d, int e)
	{
		a=d;
		b=e;
		c=a+b;
		System.out.println(c);
	}
	public void Subtraction()
	{
		a=20;
		b=10;
		c=a-b;
		System.out.println(c);
	}
}
public class Test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Add a1=new Add();
		a1.Addition();
	    a1.Subtraction();
	    a1.Addition(15, 10);
	    
	    
	}

}



