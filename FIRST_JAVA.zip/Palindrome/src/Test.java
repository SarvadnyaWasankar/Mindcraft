import java.util.Scanner;
class pali
{
	String s,r="";
	public void function()
	{
		System.out.println("Enter the string: "+ s);
		Scanner sc=new Scanner(System.in);
		s=sc.nextLine();
		int l=s.length();
		for(int i=l-1;i>=0;i--)
		{
			r=r+s.charAt(i);
		}
		if(s.equals(r))
		{
			System.out.println(s+" is a palindrome");
		      
		}
		else
		{
	         System.out.println(s+" is not a palindrome");
		}
	}
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pali a1=new pali();
		a1.function();
	}

}
