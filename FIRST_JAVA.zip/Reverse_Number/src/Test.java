import java.util.Scanner;
class reverse{
	public void func()
	{System.out.println("Enter number: ");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int r=0;
	int b=0;
	for(int i=0;i<n;i++)
	{
		b=n%10;
		n=n/10;
		r=r*10+b;
		
	}
	System.out.println(r);
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		reverse a1=new reverse();
		a1.func();
	}

}
