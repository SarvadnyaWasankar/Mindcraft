import java.util.Scanner;
class sum{
	public void func() {
		System.out.println("Enter number: ");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int s=0;
		for(int i=0;i<n;i++)
		{
			s=s+n%10;
			n=n/10;
		}
	
		System.out.println("Sum= " +s);
	}
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sum a1=new sum();
		a1.func();
		

	}

}
