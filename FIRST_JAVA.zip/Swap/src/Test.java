import java.util.Scanner;
class swap{
	public void func()
	{
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter first no: ");
        int a = sc.nextInt();

        System.out.print("Enter second no: ");
        int b = sc.nextInt();

        
        System.out.println("Before swapping: a = " + a + ",b = " + b);
        int temp = a;
        a = b;
        b = temp;
        
        System.out.println("After swapping: a = " + a + ",b = " + b);
	}

	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		swap a1=new swap();
		a1.func();

	}

}
