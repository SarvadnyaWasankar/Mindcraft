import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Employee{
	int empid;
	String name;
	double salary;
	public Employee() {
		empid=100;
		name="Sarvadnya";
		salary=10000;
	}
	public Employee(int empid, String name, double salary) {
		
		this.empid = empid;
		this.name = name;
		this.salary = salary;
	}
	
	public void accept() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		empid=sc.nextInt();
		System.out.println("Enter Employee Name");
		name=sc.next();
		System.out.println("Enter Employee Salary");
		salary=sc.nextDouble();
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + "]";
	}
	
	
	
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> e=new ArrayList<Employee>();
		Scanner sc=new Scanner(System.in);
		while(true) {
			int choice;
			System.out.println("1. Add Employee details");
			System.out.println("2. Display Employee details");
			System.out.println("3. Update Employee Details");
			System.out.println("4. Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				Employee e1=new Employee();
				e1.accept();
				e.add(e1);
				break;
				
			case 2:
				System.out.println("Details of Employee..");
				for(int i=0;i<e.size();i++) {
					System.out.println(e.get(i).empid+" "+e.get(i).name+" "+e.get(i).salary);
				}
				System.out.println();
				break;
				
			case 3:
				System.out.println("Enter Emp Id:");
				int uempid=sc.nextInt();
				double usalary;
				boolean found =false;
				for(int i=0;i<=e.size();i++) {
					if(uempid==e.get(i).empid) {
						System.out.println("Enter the updated salary:");
						usalary=sc.nextDouble();
						e.get(i).salary=usalary;
						
						found=true;
						System.out.println("Salary updated successfully.");
						break;
					}
				}
				if(!found) {
					System.out.println("Employee with Id"+uempid+"not found");
				}
				break;
				
			case 4:
				System.exit(0);
			}
		}

		

	}

}
