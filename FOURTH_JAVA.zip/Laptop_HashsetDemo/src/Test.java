import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

class laptop implements Comparable<laptop>{
	private int lid;
	String make;
	double cost;
	
	
	public laptop(int lid, String make, double cost) {
		this.lid = lid;
		this.make = make;
		this.cost = cost;
	}
	
	public void show() {
		System.out.println(lid+" "+make+" "+cost);
	}

	@Override
	public int hashCode() {
		return Objects.hash(cost, lid, make);
	}

	@Override
	public int compareTo(laptop o) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		laptop other = (laptop) obj;
		return Double.doubleToLongBits(cost) == Double.doubleToLongBits(other.cost) && lid == other.lid
				&& Objects.equals(make, other.make);
	}
	


}


class laptopcompare implements Comparable<laptopcompare>{

	@Override
	public int compareTo(laptopcompare o) {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<laptop> l=new TreeSet<laptop>();
		l.add(new laptop(101, "LG", 100000));
		laptop l1=new laptop(102, "HP", 70000);
		l.add(l1);
		System.out.println(l);
		
		
		List<laptop> l1=new
	}



}
