import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list1 =new ArrayList<>();
		list1.add("apple");
		list1.add("banana");
		list1.add("orange");
		
		System.out.println(list1);
		
		list1.add(1,"muskmelon");
		System.out.println(list1);
		//remove from index
		//list1.remove(0);
		
		//remove by word
		//list1.remove("banana");
		System.out.println(list1);
		//returns true or false
		boolean isp=list1.contains("orange");
		//System.out.println(isp);
		//returns size
		//System.out.println(list1.size());
		
		//array list size increases by 50%,default is 10
		
		//vector size increases by 100%,default is 10
		
		//execution of array list is faster than vector
		
		
		
		Iterator<String> arrayitr=list1.iterator();	
		//acts like for loop
		while(arrayitr.hasNext()) {
			String l=arrayitr.next();
			System.out.println(l);
		}
		System.out.println();
		for(String l1:list1) {
			System.out.println(l1);
		}
		
		
	}

}
