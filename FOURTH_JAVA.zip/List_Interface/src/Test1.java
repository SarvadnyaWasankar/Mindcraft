import java.util.Vector;
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Integer> v1=new Vector<>();
		
		v1.add(1);
		v1.add(2);
		v1.add(10);
		v1.add(0);
		//vector is syncronised
		System.out.println(v1);
		
		
		

	}

}
