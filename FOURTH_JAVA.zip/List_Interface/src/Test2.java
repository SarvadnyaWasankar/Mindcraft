import java.util.LinkedList;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> linkls=new LinkedList<>();

		linkls.add("apple");
		linkls.add("banana");
		linkls.add("orange");
		
		System.out.println(linkls);
	}

}
