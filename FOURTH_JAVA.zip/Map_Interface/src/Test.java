import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<Integer, String> hashmap = new HashMap<>();
		hashmap.put(3, "Sarvadnya");
		hashmap.put(1, "Rohan");
		hashmap.put(2, "Charlie");
		hashmap.put(null, "Bob");
		hashmap.put(0, null);
		//ordered according to keys
		System.out.println(hashmap);
		
		
		
		Map<Integer, String> linkedhashmap = new LinkedHashMap<>();
		linkedhashmap.put(3, "Alice");
		linkedhashmap.put(1, "Bob");
		linkedhashmap.put(2, "Charlie");
		linkedhashmap.put(null, "Bob");
		linkedhashmap.put(0, null);
		linkedhashmap.put(2, "Charlie1");
		
		
		
		
		Map<Integer, String> treemap= new TreeMap<>();
		
		treemap.put(3, "Alice");
		treemap.put(1, "Bob");
		treemap.put(2, "Charlie");
		treemap.put(4, "Bob");
		treemap.put(0, null);
		
		System.out.println(treemap);
		System.out.println(treemap.get(3));

	}

}
