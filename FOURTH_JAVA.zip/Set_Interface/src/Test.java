import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<String> hashset1=new HashSet<>();
		hashset1.add("apple");
		hashset1.add("banana");
		hashset1.add("orange");
		hashset1.add("Banana");
		
		//order of insertion is not preserved
		//duplication is not allowed
		
		System.out.println(hashset1);
		
		
		
		Set<String> treeset= new TreeSet<>();
		treeset.add("Charlie");
		treeset.add("Alice");
		treeset.add("Bob");
		treeset.add("Alice");
		//treeset automatically sorts
		System.out.println(treeset);
		
		
		for(String name:treeset) {
			System.out.println(name);
		}
		
		
		
		Set<String> linkedset=new LinkedHashSet<>();
		linkedset.add("Bob");
		linkedset.add("Charlie");
		linkedset.add("Alice");
		linkedset.add("Bob");
		
		//inserting order is preserved
		//no duplicates
		
		System.out.println(linkedset);
	}

}
