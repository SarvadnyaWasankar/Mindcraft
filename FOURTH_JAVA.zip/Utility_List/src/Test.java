import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


	
class UtilityList{
	int roll_no;
	String name;
	int grade;
	double percentage;
	public UtilityList() {
		roll_no=1;
		name="Sarvadnya";
		grade=10;
		percentage=99;
	}
	public UtilityList(int roll_no, String name, int grade, double percentage) {
		this.roll_no = roll_no;
		this.name = name;
		this.grade = grade;
		this.percentage = percentage;
	}
	
	public void createList() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student Rol No:");
		roll_no=sc.nextInt();
		System.out.println("Enter Student Name:");
		name=sc.next();
		System.out.println("Enter Student Class:");
		grade=sc.nextInt();
		System.out.println("Enter Student Percentage:");
		percentage=sc.nextDouble();
		
	}
	
	public void printList() {
		System.out.println(roll_no+" "+name+" "+grade+" "+ percentage);
	}
	
	
	
	
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<UtilityList> stu=new ArrayList<UtilityList>();
		Scanner sc=new Scanner(System.in);
		while(true) {
			int choice;
			System.out.println("1. Add Student Details");
			System.out.println("2. Display Student Details");
			System.out.println("3. Exit");
			System.out.println("Enter your choice");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				UtilityList u=new UtilityList();
				u.createList();
				stu.add(u);
				break;
				
			case 2:
				System.out.println("Details of Student:");
				for(int i=0;i<stu.size();i++)
				{
					System.out.println(stu.get(i).roll_no+" "+stu.get(i).name+" "+stu.get(i).grade+" "+stu.get(i).percentage);
				}
				System.out.println();
				break;
			case 3:
				System.exit(0);
			}
		}
		

	}

}
