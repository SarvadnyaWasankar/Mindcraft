import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.cj.jdbc.PreparedStatementWrapper;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.xdevapi.PreparableStatement;

public class Test {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		Connection c=DriverManager.getConnection("jdbc:mysql://localhost/student","root","root");
		boolean s;
		Scanner sc=new Scanner(System.in);
		System.out.println("What is your choice?");
		System.out.println("1. Insert record");
		System.out.println("2. Update record");
		System.out.println("3. Delete record");
		System.out.println("4. Display particular record");
		System.out.println("5. Display all records");
		System.out.println("6. Exit");
		
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter Rollno,Name,Percentage:");
		int rollno=sc.nextInt();
		String name=sc.next();
		int percent=sc.nextInt();
		
		
		PreparedStatement pstm=c.prepareStatement("Insert into student1 values (?,?,?)");
		pstm.setInt(1, rollno);
		pstm.setString(2, name);
		pstm.setInt(3, percent);
		s=pstm.execute();
		if(!s) {
			System.out.println("row inserted successfully");
			
		}
		c.close();	
		
		break;
		case 2:
			System.out.println("Enter roll no to update record");
			rollno=sc.nextInt();
			System.out.println("Enter updated name and marks");
			name=sc.next();
			percent=sc.nextInt();
			
		PreparedStatement p1=c.prepareStatement("Update student1 set fullname=(?),percentage=(?) where roll_no=(?)");
		p1.setString(1, name);
		p1.setInt(2, percent);
		p1.setInt(3, rollno);
		s=p1.execute();
		if(!s) {
			System.out.println("Row updated successfully");
		}
		c.close();
		break;
		
		case 3:
			System.out.println("Enter rollno to delete:");
			rollno=sc.nextInt();
			
			PreparedStatement p2=c.prepareStatement("Delete from student1 where roll_no=(?)");
			p2.setInt(1, rollno);
			s=p2.execute();
			if(!s) {
				System.out.println("Row deleted successfully");
			}
			c.close();
			break;
			
		case 4:
			System.out.println();
				System.out.println("Enter roll no to view record");
				rollno=sc.nextInt();
				
				PreparedStatement p3=c.prepareStatement("select * from student1 where roll_no=(?)");
				p3.setInt(1, rollno);
				ResultSet rs=p3.executeQuery();
				while(rs.next()) {
					System.out.println(rs.getInt(1)+" "+ rs.getString(2)+" "+rs.getInt(3));
				}
				System.out.println("Particular record displayed successfully");
				c.close();
				break;
				
		case 5:
			System.out.println("View all records");
			
			PreparedStatement p4=c.prepareStatement("select * from student1");
			ResultSet rs1=p4.executeQuery();
			while(rs1.next()) {
				System.out.println(rs1.getInt(1)+" "+ rs1.getString(2)+" "+rs1.getInt(3));
			}
			s=p4.execute();
			if(!s) {
				System.out.println("Records displayed successfully");
			}
			c.close();
			break;
		case 6:
			System.exit(0);
		}
		
		
		
		
		}

}
