import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
        //Banking bank = new Banking();
        boolean bool = true;
		PreparedStatement psmt;
		ResultSet rs;
		boolean s;
//		Scanner sc = new Scanner(System.in);
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost/banking","root","root");

        while (bool) {
            System.out.println("1. Login as Administrator");
            System.out.println("2. Login as Customer");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            switch (choice) {
            case 1:
                boolean admin = true;
                while (admin) {
                    System.out.println("1. Create Account");
                    System.out.println("2. Search Account by Name");
                    System.out.println("3. Search Account by Number");
                    System.out.println("4. Modify Account Details");
                    System.out.println("5. Balance Inquiry");
                    System.out.println("6. Close Account");
                    System.out.println("7. Logout");
                    System.out.println("Choose an option: ");
                    int AdminChoice = sc.nextInt();
                    switch (AdminChoice) {
                            case 1:
                                System.out.print("Enter Account Number: ");
                                int acno = sc.nextInt();
                                System.out.println("Enter Name: ");
                                String name = sc.next();
                                System.out.println("Enter Balance: ");
                                double balance = sc.nextDouble();
                                //bank.CreateAccount(acno, name, balance);
                                psmt = c.prepareStatement("insert into bankacc values (?,?,?)");
                				psmt.setInt(1, acno);
                				psmt.setString(2, name);
                				psmt.setDouble(3, balance);
                				s = psmt.execute();
                				
                                break;
                            case 2:
                                System.out.println("Enter Name to Search: ");
                                name = sc.next();
                                //bank.SearchAccountByName(name);
                                psmt = c.prepareStatement("select * from bankacc where acc_name = (?)");
                				psmt.setString(1, name);
                				rs = psmt.executeQuery();
                				while(rs.next())  {
                					System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
                				}
                				System.out.println();
                                break;
                            case 3:
                                System.out.println("Enter Account Number to Search: ");
                                acno = sc.nextInt();
                                //bank.SearchAccountByNumber(acno);
                                psmt = c.prepareStatement("select * from bankacc where acc_no = (?)");
                 				psmt.setInt(1, acno);
                 				rs = psmt.executeQuery();
                 				while(rs.next())  {
                 					System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
                				}
                 				System.out.println();
                                break;
                            case 4:
                                System.out.println("Enter Account Number to Modify: ");
                                acno = sc.nextInt();
                                System.out.println("Enter New Name: ");
                                name = sc.next();
                                //bank.ModifyAccount(acno, name);
                				psmt = c.prepareStatement("update bankacc set acc_name = (?) where acc_no = (?)");
                				psmt.setInt(2, acno);
                				psmt.setString(1, name);
                				s = psmt.execute();
                				if(!s) {
                					System.out.println("Row Updated Successfully");
                				}
                				break;
                            case 5:
                                System.out.println("Enter Account Number for Balance Inquiry: ");
                                acno = sc.nextInt();
                                //bank.BalanceInquiry(acno);
                                psmt = c.prepareStatement("select acc_bal from bankacc where acc_no = (?)");
                				psmt.setInt(1, acno);
                				rs = psmt.executeQuery();
                 				while(rs.next())  {
                 					System.out.println(rs.getInt(1));  
                				}
                                break;
                            case 6:
                                System.out.println("Enter Account Number to Close: ");
                                acno = sc.nextInt();
                                //bank.CloseAccount(acno);
                				psmt = c.prepareStatement("delete from bankacc where acc_no = (?)");
                				psmt.setInt(1, acno);
                				s = psmt.execute();
                				if(!s) {
                					System.out.println("Row Delete Successfully");
                				}
                                break;
                            case 7:
                                admin = false;
                                break;
                        }
                    } 
                break;

            case 2:
                boolean customer = true;
                while (customer) {
                    System.out.println("1. Deposit");
                    System.out.println("2. Withdraw");
                    System.out.println("3. Print Mini Statement");
                    System.out.println("4. Transfer");
                    System.out.println("5. Logout");
                    System.out.print("Choose an option: ");
                    int CustomerChoice = sc.nextInt();
                    switch (CustomerChoice) {
                    	case 1:
                    		System.out.print("Enter Account Number: ");
                    		int acno = sc.nextInt();
                            System.out.print("Enter Amount to Deposit: ");
                            double DepositAmt = sc.nextDouble();
                            //bank.Deposit(acno, DepositAmt);
            				psmt = c.prepareStatement("update bankacc set acc_bal = acc_bal+(?) where acc_no = (?)");
            				psmt.setInt(2, acno);
            				psmt.setDouble(1, DepositAmt);
            				s = psmt.execute();
            				if(!s) {
            					System.out.println("Deposit done Successfully");
            				}
                            break;
                    	case 2:
                    		System.out.print("Enter Account Number: ");
                            acno = sc.nextInt();
                            System.out.print("Enter Amount to Withdraw: ");
                            double WithdrawAmt = sc.nextDouble();
                            //bank.Withdraw(acno, WithdrawAmt);
            				psmt = c.prepareStatement("update bankacc set acc_bal = acc_bal-(?) where acc_no = (?)");
            				psmt.setInt(2, acno);
            				psmt.setDouble(1, WithdrawAmt);
            				s = psmt.execute();
            				if(!s) {
            					System.out.println("Withdraw done Successfully");
            				}
                            break;
                    	case 3:
                            System.out.print("Enter Account Number: ");
                            acno = sc.nextInt();
                            //bank.PrintMiniStatement(acno);
                            break;
                    	case 4:
                            System.out.print("Enter From Account Number: ");
                            int FromAcc = sc.nextInt();
                            System.out.print("Enter To Account Number: ");
                            int ToAcc = sc.nextInt();
                            System.out.print("Enter Amount to Transfer: ");
                            double TransferAmt = sc.nextDouble();
                            //bank.Transfer(FromAcc, ToAcc, TransferAmt);
             				psmt = c.prepareStatement("update bankacc set acc_bal = acc_bal-(?) where acc_no = (?)");
            				psmt.setInt(2, FromAcc);
            				psmt.setDouble(1, TransferAmt);
            				s = psmt.execute();
            				if(!s) {
            					System.out.println("Transfer(Withdraw) done Successfully");
            				}
            				psmt = c.prepareStatement("update bankacc set acc_bal = acc_bal+(?) where acc_no = (?)");
            				psmt.setInt(2, ToAcc);
            				psmt.setDouble(1, TransferAmt);
            				s = psmt.execute();
            				if(!s) {
            					System.out.println("Transfer(Deposit) done Successfully");
            				}
                            break;
                    	case 5:
                            customer = false;
                            break;
                        }
                }
                break;

            case 3:
                customer = false;
                c.close();
                System.exit(0);
        }
    }

		
		
		
	}

}
