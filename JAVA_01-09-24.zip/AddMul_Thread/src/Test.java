import java.util.Scanner;

class add extends Thread{
	
	int a;
	

	public add(int a) {
		this.a = a;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<=a+10;i++) {
			System.out.println("Add:"+i);
			
			
		}
	}

	
}

class mul extends Thread{
	int b;

	public mul(int b)
	{
		this.b=b;
	}
	public void run()
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(b+"*"+i+":" +b*i);
		}
			
	}

}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a,b;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value for addition:");
		a=sc.nextInt();
		System.out.println("Enter the value for multiplication:");
		b=sc.nextInt();
		
		Thread t1=new Thread(new add(a));
		t1.start();
		Thread t2=new Thread(new mul(b)) ;
		t2.start();

	}

}

