import java.util.Scanner;

class Armstrong{
	int n,org_n;
	double sum_cube;
	
	public void Check_arm() {
		System.out.println("Enter the number:");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		org_n=n;
		sum_cube=0;
		
		while(n>0) {
			int rem=n%10;
			sum_cube=sum_cube+Math.pow(rem, 3);
			n=n/10;
		}
		if(org_n==sum_cube) {
			System.out.println("It is an armstrong number");
		
		}
		else {
			System.out.println("It is not an armstrong number");
		}
	}
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Armstrong a1=new Armstrong();
		a1.Check_arm();

	}

}
