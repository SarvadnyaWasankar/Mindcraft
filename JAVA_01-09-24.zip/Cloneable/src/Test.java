class Vehicle implements Cloneable{
	private String vname;
	private int vnumber;
	
	private double cost;
	
	
	public Vehicle() {
		vname="";
		vnumber=0;
		cost=0;
	}

	
	
	public Vehicle(String vname, int vnumber, double cost) {
		super();
		this.vname = vname;
		this.vnumber = vnumber;
		this.cost = cost;
	}


	public void show() {
		System.out.println(vname+" "+vnumber+" "+cost);
	}



	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}


	
	
	
}
public class Test {

	public static void main(String[] args)  throws CloneNotSupportedException{
		// TODO Auto-generated method stub
		Vehicle v=new Vehicle("bmw", 123214, 2332344);
		v.show();
		Vehicle v1=(Vehicle)v.clone();
		v1.show();
		
	}

}
