import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

class person implements Comparable<person>{
	String name;
	int age;
	public person(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "person [name=" + name + ", age=" + age + "]";
	}
	@Override
	public int compareTo(person o) {
		// TODO Auto-generated method stub
		return Integer.compare(this.age,o.age);
	}
	
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<person> people=new ArrayList<>();
		people.add(new person("Sarvadnya", 23));
		people.add(new person("Charlie", 20));
		people.add(new person("Bob", 25));
		people.add(new person("Alice", 25));
		
		Collections.sort(people);
		System.out.println(people);

	}

}
