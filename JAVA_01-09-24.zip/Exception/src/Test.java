class Account{
	protected double balance;

	public Account(double balance) {
		super();
		this.balance = balance;
	}
	 public void deposit(double amount) {
		 balance=balance+amount;
	 }
	 
	 public void withdraw(double amount) throws Exception{
		 if(amount>balance) {
			 throw new Exception("Insufficient Balance...");
			 
		 }
		 else if(amount>15000) {
			 throw new Exception("Overlimit..");
			 
		 }
		 else {
			 balance=balance-amount;
		 }
	 }
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account acc=new Account(30000);
		try {
			acc.withdraw(10000);
			System.out.println(acc.balance);
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		} 

	}

}
