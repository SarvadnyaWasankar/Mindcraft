//class ThredDemo implements Runnable

class ThredDemo extends Thread{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++) {
			System.out.println(Thread.currentThread().getName()+"count:"+i);
			try {
				Thread.sleep(1000);
				
			}
			catch (InterruptedException e) {
				// TODO: handle exception
				System.out.println(e);
			}
		}
		
	}
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t1=new Thread(new ThredDemo(),"Thread-1");
		Thread t2=new Thread(new ThredDemo(),"Thread-2");
		t1.start();
		t2.start();
		

	}

}
