package in.mindcraft.Account_inheritance;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Account acc=new Account();
		System.out.println("Enter account details:");
		acc.display();
		System.out.println();
		
		
		SavingsAccount sacc=new SavingsAccount();
		System.out.println("Enter savings account details:");
		sacc.display();
		sacc.setInterestRate(9);
		System.out.println();
		
		
		CurrentAccount cacc=new CurrentAccount();
		System.out.println("Enter current Account details:");
		cacc.display();
		cacc.setOverlimit(15000);
		
		

		// Create a StandardServiceRegistry
        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                .configure() // This reads hibernate.cfg.xml
                .build();

        // Create MetadataSources
        MetadataSources metadataSources = new MetadataSources(standardRegistry);

        // Create Metadata
        Metadata metadata = metadataSources.getMetadataBuilder().build();

        // Create SessionFactory
        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

        // Open a session and begin a transaction
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        // Save the objects
        session.save(acc);
        session.save(sacc);
        session.save(cacc);

        // Commit the transaction
        transaction.commit();

        // Close the session and session factory
        session.close();
        sessionFactory.close();

	}

}
