package in.mindcraft.EmpDemo;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;


public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1=new Employee();
		e1.setEmpid(1);
		e1.setName("Sarvadnya");
		
		Employee e2=new Employee();
		e2.setEmpid(2);
		e2.setName("Charlie");
		
		
		Address a1=new Address();
		a1.setCity_id(11);
		a1.setStreet("Charkop");
		a1.setCity("Mumbai");
		a1.setState("Maharashtra");
		
		
		Address a2=new Address();
		a2.setCity_id(11);
		a2.setStreet("Charkop");
		a2.setCity("Mumbai");
		a2.setState("Maharashtra");
		
		//one to many
		
		e1.getList().add(a1);
		e1.getList().add(a2);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		StandardServiceRegistry standardRegistry=new StandardServiceRegistryBuilder()
				.configure()
				.build();
		
		
		MetadataSources metadataSources=new MetadataSources(standardRegistry);
		
		Metadata metadata= metadataSources.getMetadataBuilder().build();
		
		SessionFactory sessionFactory=metadata.getSessionFactoryBuilder().build();
		
		Session session = sessionFactory.openSession();
		
		Transaction transaction=session.beginTransaction();
		
		
		session.save(e1);
		session.save(e2);
		session.save(a1);
		session.save(a2);
		
		
		transaction.commit();
		
		session.close();
		sessionFactory.close();
		
		}

}
