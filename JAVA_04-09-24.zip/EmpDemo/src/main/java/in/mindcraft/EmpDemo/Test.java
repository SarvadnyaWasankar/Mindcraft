package in.mindcraft.EmpDemo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Test {
    public static void main(String[] args) {
        // Create instances of Employee and Address
        Employee e1 = new Employee();
        e1.setEmpid(1);
        e1.setName("Sarvadnya");

        Employee e2 = new Employee();
        e2.setEmpid(2);
        e2.setName("Charlie");

        Address a1 = new Address();
        a1.setCity_id(11);
        a1.setStreet("Jankalyan");
        a1.setCity("Mumbai");
        a1.setState("Maharashtra");

        Address a2 = new Address();
        a2.setCity_id(12);
        a2.setStreet("Udhana");
        a2.setCity("Surat");
        a2.setState("Gujarat");

        Address a3 = new Address();
        a3.setCity_id(13);
        a3.setStreet("Kalyan");
        a3.setCity("Mumbai");
        a3.setState("Maharashtra");

        // empid=1 has two addresses a1, a2
        e1.getList().add(a1);
        e1.getList().add(a2);

        e2.getList().add(a3);

        // Create a StandardServiceRegistry
        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                .configure() // This reads hibernate.cfg.xml
                .build();

        // Create MetadataSources
        MetadataSources metadataSources = new MetadataSources(standardRegistry);

        // Create Metadata
        Metadata metadata = metadataSources.getMetadataBuilder().build();

        // Create SessionFactory
        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

        // Open a session and begin a transaction
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();

        // Save the entities
        session.save(e1);
        session.save(e2);
        session.save(a1);
        session.save(a2);
        session.save(a3);

        // Commit the transaction
        transaction.commit();

        // Clean up
        session.close();
        sessionFactory.close();
    }
}
