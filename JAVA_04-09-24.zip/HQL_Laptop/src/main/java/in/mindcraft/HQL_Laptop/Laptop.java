package in.mindcraft.HQL_Laptop;

import java.util.Scanner;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Laptop {
	
	
	@Id
	private int lid;
	private String name;
	private double cost;
	public Laptop(int lid, String name, double cost) {
		super();
		this.lid = lid;
		this.name = name;
		this.cost = cost;
	}
	public int getLid() {
		return lid;
	}
	public void setLid(int lid) {
		this.lid = lid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	
	public void display() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter laptop details:");
		System.out.println("Enter laptop name:");
		name=sc.next();
		System.out.println("Enter laptop cost:");
		cost=sc.nextDouble();
	}
	

}
