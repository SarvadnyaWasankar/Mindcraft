package in.mindcraft.HQL_Laptop;

import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;


public class Test {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Laptop l1=new Laptop(1, "Dell", 110000);
		Laptop l2=new Laptop(2, "HP", 80000);
		Laptop l3=new Laptop(3, "Acer", 110000);
		
		
		
		
		// Create a StandardServiceRegistry
        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                .configure() // This reads hibernate.cfg.xml
                .build();

        // Create MetadataSources
        MetadataSources metadataSources = new MetadataSources(standardRegistry);

        // Create Metadata
        Metadata metadata = metadataSources.getMetadataBuilder().build();

        // Create SessionFactory
        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

        // Open a session and begin a transaction
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
        
        session.save(l1);
        session.save(l2);
        session.save(l3);
        
     // HQL Query to retrieve mobile phones with cost >= 100000
//        Query<Laptop> q = session.createQuery("from Laptop where cost >= 100000", Laptop.class);
//        List<Laptop> mlist = q.list();
//        for (Laptop m : mlist)
//            System.out.println(m);
        
        transaction.commit();
        
        Scanner sc=new Scanner(System.in);
        int choice;
        
        while(true) {
        	System.out.println("1. Delete laptop details:");
        	System.out.println("2. Update laptop details");
        	System.out.println("Please select the Operation:");
        	
        	choice=sc.nextInt();
        	
        	switch(choice) {
        	case 1:
        		System.out.println("Enter laptop ID to delete:");
        		
        		int laptopIdToDelete = sc.nextInt();
        		transaction=session.beginTransaction();
        		@SuppressWarnings("rawtypes") 
        		Query deleteQuery = session.createQuery("delete from Laptop where lid = :lid");
                deleteQuery.setParameter("lid", laptopIdToDelete);

                int result = deleteQuery.executeUpdate();
                if (result > 0) {
                    System.out.println("Laptop with ID " + laptopIdToDelete + " deleted successfully.");
                } else {
                    System.out.println("No Laptop found with ID " + laptopIdToDelete + ".");
                }
                transaction.commit();
                break;
                
        	case 2:
        		System.out.println("Enter Laptop ID to Update:");
        		int laptopIdToUpdate = sc.nextInt();
        		
        		transaction = session.beginTransaction();
        		@SuppressWarnings("rawtypes")
        		Query updateQuery = session.createQuery("update Laptop set name = :name, cost = :cost where lid = :lid");
        		updateQuery.setParameter("lid", laptopIdToUpdate);
        		System.out.println("Enter Laptop Name:");
        		updateQuery.setParameter("name", sc.next());
        		System.out.println("Enter Laptop Cost:");
        		updateQuery.setParameter("cost", sc.nextDouble());
        		result = updateQuery.executeUpdate();
        		System.out.println("Rows Updated Successfully");
        		
        		transaction.commit();
        		break;
        	
        	case 3:
                session.close();
                sessionFactory.close();
                sc.close();
                System.exit(0);
                break;

            default:
                System.out.println("Invalid choice. Please try again.");
                break;


        		
        		
        	}
        }


	}

}
