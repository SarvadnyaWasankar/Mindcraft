package in.mindcraft.StudDemo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Laptop {
	@Id
	private int l_id;
	private String lname;
	private double makecost;
	public int getL_id() {
		return l_id;
	}
	public void setL_id(int l_id) {
		this.l_id = l_id;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public double getMakecost() {
		return makecost;
	}
	public void setMakecost(double makecost) {
		this.makecost = makecost;
	}
	
	//@OneToMany
	//private List<Student> sl1=new ArrayList<Student>();
	//public List<Student> getSl1() {
	//	return sl1;
	//}
	//public void setSl1(List<Student> sl1) {
	//	this.sl1 = sl1;
	//}
	
	@ManyToMany
	private List<Student> sl2=new ArrayList<Student>();
	public List<Student> getSl2() {
		return sl2;
	}
	public void setSl2(List<Student> sl2) {
		this.sl2 = sl2;
	}
	
	
	
	
	

}
