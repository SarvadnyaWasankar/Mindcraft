package in.mindcraft.StudDemo;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;



@Entity
public class Student {
	@Id
	private int s_id;
	private String name;
	public int getS_id() {
		return s_id;
	}
	public void setS_id(int s_id) {
		this.s_id = s_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
//	@OneToMany
//	private List<Laptop> l1=new ArrayList<Laptop>();
//	public List<Laptop> getL1() {
//		return l1;
//	}
//	public void setL1(List<Laptop> l1) {
//		this.l1 = l1;
//	}
	
	@ManyToMany
	private List<Laptop> l2=new ArrayList<Laptop>();
	public List<Laptop> getL2() {
		return l2;
	}
	public void setL2(List<Laptop> l2) {
		this.l2 = l2;
	}
	
	

}
