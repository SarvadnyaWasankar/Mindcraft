package in.mindcraft.StudDemo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student();
		s1.setS_id(1);
		s1.setName("Sarvadnya");
		
		Student s2=new Student();
		s2.setS_id(2);
		s2.setName("Charlie");
		
		
		Student s3=new Student();
		s3.setS_id(3);
		s3.setName("Bob");
		
		
		Laptop la1=new Laptop();
		la1.setL_id(10);
		la1.setLname("Dell");
		la1.setMakecost(60000);
		
		
		Laptop la2=new Laptop();
		la2.setL_id(11);
		la2.setLname("HP");
		la2.setMakecost(70000);
		
		Laptop la3=new Laptop();
		la3.setL_id(12);
		la3.setLname("Acer");
		la3.setMakecost(80000);
		
		
//		s1.getL1().add(la1);
//		s1.getL1().add(la2);
//		s1.getL1().add(la3);
		
		
		s1.getL2().add(la1);
		s1.getL2().add(la2);
		s2.getL2().add(la2);
		
		
//		
//		la2.getSl1().add(s1);
//		la2.getSl1().add(s2);
//		la2.getSl1().add(s3);
		
		la1.getSl2().add(s1);
		la1.getSl2().add(s2);
		la2.getSl2().add(s2);
		
		
		 // Create a StandardServiceRegistry
        StandardServiceRegistry standardRegistry = new StandardServiceRegistryBuilder()
                .configure() // This reads hibernate.cfg.xml
                .build();

        // Create MetadataSources
        MetadataSources metadataSources = new MetadataSources(standardRegistry);

        // Create Metadata
        Metadata metadata = metadataSources.getMetadataBuilder().build();

        // Create SessionFactory
        SessionFactory sessionFactory = metadata.getSessionFactoryBuilder().build();

        // Open a session and begin a transaction
        Session session = sessionFactory.openSession();
        Transaction transaction = session.beginTransaction();
		
        session.save(s1);
        session.save(s2);
        session.save(s3);
        session.save(la1);
        session.save(la2);
        session.save(la3);
		
        transaction.commit();
        session.close();
        
        sessionFactory.close();
		
	}

}
