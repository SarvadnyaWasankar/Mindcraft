package in.mindcraft;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegForm {
	
	@RequestMapping("/reg")
	public ModelAndView display(HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Name Display..");
		String name=request.getParameter("name");
		int mobile=Integer.valueOf(request.getParameter("mobile"));
		String email=request.getParameter("email");
		String gender=request.getParameter("gender");
		
		
		ModelAndView mv=new ModelAndView();
		mv.setViewName("result.jsp");
		mv.addObject("name", name);
		mv.addObject("gender", gender);
		mv.addObject("mobile", mobile);
		mv.addObject("email", email);
		
		return mv;
		
	}

}
