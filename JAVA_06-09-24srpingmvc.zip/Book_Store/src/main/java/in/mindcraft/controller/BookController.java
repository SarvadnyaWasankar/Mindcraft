package in.mindcraft.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import in.mindcraft.dao.BookDao;
import in.mindcraft.pojos.Book;


@Controller
public class BookController {
	
	private BookDao bookdao=new BookDao();
	
	@RequestMapping("/showbooks")
	public ModelAndView showbooks() throws ClassNotFoundException{
		ModelAndView mv=new ModelAndView();
		
		try {
			List<Book> list=bookdao.getBooks();
			System.out.println(list);
			mv.setViewName("result.jsp");
			mv.addObject("list", list);	
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		return mv;
	}
	
	@RequestMapping("/insertbooks")
	public void addBook(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException{
		
		int bid=Integer.parseInt(request.getParameter("bid"));
		String title=request.getParameter("title");
		String author=request.getParameter("author");
		double price=Double.parseDouble(request.getParameter("price"));
		
		Book book=new Book(bid, title, author, price);
		
		bookdao.addBook(book);
	}
	
	
	@RequestMapping("/updatebooks")
	public void updateBook(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException{
		
		int bid=Integer.parseInt(request.getParameter("bid"));
		String title=request.getParameter("title");
		String author=request.getParameter("author");
		double price=Double.parseDouble(request.getParameter("price"));
		
		 Book book=new Book(bid, title, author, price);
		 
		 bookdao.updateBook(book);
		
	}
	
	 @RequestMapping("/deletebooks")
	    public void deleteBook(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, SQLException {
	    	
	    	int bid=Integer.parseInt(request.getParameter("bid"));
	    	bookdao.deleteBook(bid);
	    }

}
