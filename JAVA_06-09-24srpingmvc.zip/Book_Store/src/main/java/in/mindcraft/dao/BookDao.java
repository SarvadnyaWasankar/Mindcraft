package in.mindcraft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import in.mindcraft.pojos.Book;
import in.mindcraft.utils.DBUtils;

public class BookDao {
	
	private Connection cn;
	
	private PreparedStatement pst1;
	private PreparedStatement pst2;
	private PreparedStatement pst3;
	private PreparedStatement pst4;
	
	
	public List<Book> getBooks() throws SQLException, ClassNotFoundException{
		cn=DBUtils.openConnection();
		List<Book> list=new ArrayList<Book>();
		pst1=cn.prepareStatement("select * from book");
		ResultSet rs=pst1.executeQuery();
		while(rs.next()) {
			list.add(new Book(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4)));
		}
		DBUtils.closedConnection();
		return list;
	}
	
	
	public void addBook(Book book) throws SQLException, ClassNotFoundException{
		cn=DBUtils.openConnection();
		
		pst2=cn.prepareStatement("insert into book value(?,?,?,?)");
		pst2.setInt(1, book.getBid());
		pst2.setString(2, book.getTitle());
		pst2.setString(3, book.getAuthor());
		pst2.setDouble(4, book.getPrice());
		
		pst2.execute();
		DBUtils.closedConnection();
		
	}
	
	public void updateBook(Book book) throws SQLException, ClassNotFoundException{
		cn=DBUtils.openConnection();
		
		pst3=cn.prepareStatement("update book set title=(?), author=(?), price=(?) where bid=(?)");
		
		pst3.setInt(4, book.getBid());
		pst3.setString(1, book.getTitle());
		pst3.setString(2, book.getAuthor());
		pst3.setDouble(3, book.getPrice());
		
		pst3.execute();
		DBUtils.closedConnection();
		
	}
	
	
	public void deleteBook(int bid) throws SQLException, ClassNotFoundException{
		cn=DBUtils.openConnection();
		
		pst4=cn.prepareStatement("delete from book where bid=(?)");
		
		pst4.setInt(1, bid);
		
		pst4.execute();
		DBUtils.closedConnection();
		

	}

}
