
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]a= {{1,2,3},{4,5,6},{7,8,9}};
		int [][]b= {{1,2,3,4},{5,6},{7,8,9}};
		int [][]c=new int[3][4];
		int[][]d=new int[3][];
		
		
		
		
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		for(int [] temp:b) {
			for(int val:temp) {
				System.out.print(val+" ");
			}
			System.out.println();
		}

	}

}
