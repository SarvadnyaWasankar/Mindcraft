import java.util.Scanner;

class mat{
	int [][]b=new int[3][3];
	Scanner sc=new Scanner(System.in);
	
	public void tran(int a[][])
	{
		for(int i = 0; i <a.length; i++) 
		{
			for (int j = 0; j < a[i].length; j++) {
                 b[j][i] = a[i][j];
                 }
		}
		for(int []temp:b) {
			for(int val:temp)
			{
				System.out.print(val+" ");
			}
			System.out.println();
		}
	}
	public void add() {
		int [][]d=new int[3][3];
		int [][]s=new int[3][3];
		System.out.println("Enter Matrix:");
		
		for(int i = 0; i <d.length; i++) 
		{
			for (int j = 0; j < d[i].length; j++) {
                  d[i][j]=sc.nextInt();
                 }
		}
		for(int i=0;i<d.length;i++) {
			for(int j=0;j<d[i].length;j++)
			{
				s[i][j]= d[i][j]+b[i][j];
				
			}
		}
		System.out.println();
		System.out.println("Sum:");
		for(int [] temp:s) {
			for(int val:temp) {
				System.out.println(val+" ");
			}
			System.out.println();
		}
		
		
            
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [][]a=new int[3][3];
		System.out.println("Enter matrix:");
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		mat a1=new mat();
		a1.tran(a);
		a1.add();
		
	}

}
}
