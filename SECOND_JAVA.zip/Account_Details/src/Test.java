import java.util.Scanner;

class AccountHolder{
	private int acc_no;
	private String acc_name;
	private double balance;
	
	// Generate Parameterized constructor
	public AccountHolder(int acc_no, String acc_name, double balance) {
		this.acc_no = acc_no;
		this.acc_name = acc_name;
		this.balance = balance;
	}
	
	// generate getter and setter
	public int getAcc_no() {
		return acc_no;
	}
	public void setAcc_no(int acc_no) {
		this.acc_no = acc_no;
	}
	public String getAcc_name() {
		return acc_name;
	}
	public void setAcc_name(String acc_name) {
		this.acc_name = acc_name;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void deposit(double amt) {
		balance=amt+balance;
	}
	public void withdraw(double amt) {
		balance=balance-amt;
	}
	
	public void details()
	{
		System.out.println(acc_no+"\t"+acc_name+"\t"+balance);
	}
	
	
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cnt=0,choice,accno;
		double wamt;
		AccountHolder acc[]=new AccountHolder[10];

		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("1. Add Account Details'");
			System.out.println("2. Display Account Details");
			System.out.println("3. Deposit Amount");
			System.out.println("4. Withdraw ammount");
			System.out.println("5. Exit");
			
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			switch(choice) {
			
			case 1:
				System.out.println("Enter Account Number, Account Holder Name, Account Balance ");
				acc[cnt++]=new AccountHolder(sc.nextInt(),sc.next(),sc.nextDouble());
				break;
				
			case 2:
				System.out.println("All Account details");
				for(int i=0;i<cnt;i++) {
					acc[i].details();
				};
				System.out.println();
				break;
				
			case 3:
				System.out.println("Enter Account number for deposit:");
				accno=sc.nextInt();
				for(int i=0;i<cnt;i++)
				{
					if(accno==acc[i].getAcc_no())
					{
						System.out.println("Amount deposit:");
						acc[i].deposit(sc.nextDouble());
					}
					else {
						System.out.println("Account details not found");
					}
				}
				break;
				
			case 4:
				System.out.println("Enter Account number for withdraw1");
				accno=sc.nextInt();
				for(int i=0;i<cnt;i++) 
				{
					if(accno==acc[i].getAcc_no()) {
						System.out.println("Amount  Withdraw");
						wamt=sc.nextDouble();
						if(wamt>acc[i].getBalance())
						{
							System.out.println("insufficent balance");
						}
						else {
							acc[i].withdraw(wamt);
						}
					}
					else {
						System.out.println("Account details not found");
						
					}
					
				}
				break;
			case 5:
				System.exit(0);
			}
		}
		

	}

}
