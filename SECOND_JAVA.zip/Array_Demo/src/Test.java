import java.util.Scanner;


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int [] a=new int[5];
		int [] b= {10,20,30};
		float []c=new float[10];
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 5 numbers: ");
		for(int i=0;i<a.length;i++) {
			a[i]=sc.nextInt();
		}
//		for(int i=0;i<a.length;i++) {
	//		System.out.println(a[i]);
//		}
		
		System.out.println("for each");
		for(int val:a) {
			System.out.println(val);
		}
	}

}
