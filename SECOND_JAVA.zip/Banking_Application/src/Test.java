import java.util.Scanner;
class banking{
	int account_number,balance,wamount,damount;
	String account_holder_name;
	public void accountdetails() {
		Scanner sc2=new Scanner(System.in);
		System.out.println("Name: ");
		account_holder_name=sc2.next();
		System.out.println("Account Number: ");
		account_number=sc2.nextInt();
		
	}
	public void deposit()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Balance: ");
		balance=sc.nextInt();
		System.out.println("Enter deposit amount: ");
		damount=sc.nextInt();
		balance=balance+damount;
		System.out.println("Final Balance: "+balance);
		
	}
	public void withdraw(){
		Scanner sc1=new Scanner(System.in);
		System.out.println("Balance: ");
		balance=sc1.nextInt();
		System.out.println("Enter withdraw amount: ");
		wamount=sc1.nextInt();
		balance=balance- wamount;
		System.out.println("Remaining Balance: "+balance);
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		banking a1=new banking();
		a1.accountdetails();
		String a2;
		System.out.println("Withdraw,Deposit,Details" );
		Scanner sc3=new Scanner(System.in);
		a2=sc3.next();
		switch(a2)
		{
		case "Withdraw":
			a1.withdraw();
			break;
		case "Deposit":
			a1.deposit();
			break;
		case "Details":
			a1.accountdetails();
			break;
		
		}
		

	}

}


