import java.util.Scanner;
class Employee{
	int emp_id,salary,bonus,total;
	String name,dept;
	public void func() {
		System.out.println("Enter Employee ID: ");
		Scanner sc=new Scanner(System.in);
		emp_id=sc.nextInt();
		System.out.println("Enter Employee Name: ");
		name = sc.next();
		System.out.println("Enter Department: ");
		dept = sc.next();
		System.out.println("Enter Salary: ");
		salary = sc.nextInt();
		System.out.println("Enter Bonus Percentage: ");
		bonus = sc.nextInt();
		
		total=salary+ (salary*bonus)/100;
		System.out.println("Employee_ID: " + emp_id);
		System.out.println("Name: "+ name);
		System.out.println("Department: "+ dept);
		System.out.println("Salary: "+ total);
		
		
		
	}
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee a1=new Employee();
		a1.func();

	}

}
