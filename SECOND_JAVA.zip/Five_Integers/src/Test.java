import java.util.Scanner;

class maxmin{
	int max,min;
	public void maxi(int a[]){
		max=a[0];
		for(int i=0;i<a.length;i++)
		{
			if(a[i]>max)
			{
				max=a[i];
			}
		}
		System.out.println("Max: "+ max);
	}
	public void mini(int a[]){
		int min=a[0];
		for(int i=0;i<a.length;i++)
		{
			if(a[i]<min)
			{
				min=a[i];
			}
		}
		System.out.println("MIn: "+min);
	}
	
	public void mul(int a[]) {
		int b[]=new int[5];
		
		for(int i=0;i<b.length;i++ )
		{
			for(int j=0;j<a.length;j++)
			{
			b[i]=a[i]*5;
			}
			
		}
		for(int val:b) {
			System.out.print(val+" ");
		}
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a=new int[5];
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter 5 numbers:");
		for(int i=0;i<a.length;i++)
		{
			a[i]=sc.nextInt();
		}
		
		maxmin a1=new maxmin();
		a1.maxi(a);
		a1.mini(a);
		a1.mul(a);
	}

}
