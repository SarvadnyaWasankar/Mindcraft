import java.util.Scanner;

class Student{
	private int roll_no;
	private String name;
	private double percentage;
	static int count=0;
	public Student(int roll_no, String name, double percentage) {
		this.roll_no = roll_no;
		this.name = name;
		this.percentage = percentage;
		count++;
	}
	public int getRoll_no() {
		return roll_no;
	}
	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	
	}
	public void details() {
		System.out.println(roll_no+"\t"+name+"\t"+percentage);
	}
	public static int getCount() {
		return count;
	}

	
	
	
	
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0,choice;
		Student stu[]=new Student[10];
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("1. Enter Student Details");
			System.out.println("2. Count Objects");
			System.out.println("3. Student Details");
			System.out.println("4. Exit");
			System.out.println("Enter you choice");
			choice=sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter Roll Number, Name, Percentage");
				stu[count++]=new Student(sc.nextInt(),sc.next(),sc.nextDouble());
				break;
			case 2:
				System.out.println("Student Count:"+Student.getCount());
				break;
			case 3:
				System.out.println("Student Details");
				for(int i=0;i<count;i++)
				{
					stu[i].details();
				}
				break;
			case 4:
				System.exit(0);
				
			}
		}

	}

}
