abstract class Animal{
	abstract void sound();
}

class dog extends Animal{
	void sound() {
		System.out.println("dog barks...");
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dog d=new dog();
		d.sound();

	}

}
