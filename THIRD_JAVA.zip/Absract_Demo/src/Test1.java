
interface showable{
	void show();
}

abstract class lib{
	abstract void store();
}
class doc extends lib implements showable{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("show doc...");
		
	}

	@Override
	void store() {
		// TODO Auto-generated method stub
		System.out.println("store doc...");
	}
	
}
public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		doc d=new doc();
		d.show();
		d.store();

	}

}

