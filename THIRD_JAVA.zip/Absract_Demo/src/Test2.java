class animal1{
	public void sound() {
		System.out.println("animal makes sound...");
	}
}

class dog1 extends animal1{
	public void sound() {
		System.out.println("dog barks...");
	}
}
public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		animal1 a1=new animal1();
		a1.sound();
		animal1 a2=new dog1();
		a2.sound();

	}

}
