
import in.mindcraft.WageEmployee;
import in.mindcraft.SalesPerson;
public class Test{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WageEmployee w1=new WageEmployee(10, "Sarvadnya", 01, 12, 2000, 30, 100);
		w1.show();
		System.out.println();
		SalesPerson w2=new SalesPerson(11,200,50,"Charlie", 10,11,2000,50,200);
		w2.show();

	}

}
