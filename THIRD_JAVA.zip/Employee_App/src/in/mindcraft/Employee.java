package in.mindcraft;

public class Employee {
	private int empid;
	private String ename;
	private Date dob;
	
	public Employee() {
		empid=10;
		ename="Sarvadnya";
		dob=new Date();
	}
	public Employee(int empid, String ename, int dd,int mm,int yy) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.dob = new Date(dd,mm,yy);
	}
	
	public void show() {
		System.out.println("Employee Id"+ empid);
		System.out.println("Employee Name"+ ename);
		System.out.println("Date of Birth"+ dob);
	}
	
	

}
