package in.mindcraft;

public class SalesPerson extends WageEmployee {
	private int itemssold;
	private double comm;
	private int hours;
	private int rate;
	public SalesPerson() {
		itemssold=0;
		comm=0;
	}
	public SalesPerson(int itemssold,int comm,int empid, String ename, int dd, int mm, int yy,int hours,int rate) {
		super(empid,ename,dd,mm,yy,hours,rate);
		this.itemssold=itemssold;
		this.comm=comm;
		this.hours=hours;
		this.rate=rate;
	}
	public void show() {
		super.show();
		System.out.println("Items Sold:"+itemssold);
		System.out.println("Commission"+comm);
		System.out.println("SalesPerson Salary:"+(hours*rate+itemssold*comm));
	}

}
