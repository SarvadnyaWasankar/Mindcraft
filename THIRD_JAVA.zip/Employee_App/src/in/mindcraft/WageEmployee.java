package in.mindcraft;

public class WageEmployee extends Employee{
	
	private int hours;
	private int rate;
	
	public WageEmployee() {
		hours=0;
		rate=0;
	}
	
	
	public WageEmployee(int empid, String ename,int dd,int mm,int yy,int hours,int rate)
	{
		super(empid,ename,dd,mm,yy);
		this.hours=hours;
		this.rate=rate;
		
	}
	public void show() {
		super.show();
		System.out.println("Hours:"+hours);
		System.out.println("Rate:"+rate);
		System.out.println("WageEmployee Salary:"+hours*rate);
	}
	
	

}

	
