package EmployeeApp;


public class Employee {
	private int empid;
	private String name;
	private int bsalary;
	
	public Employee() {
		empid=10;
		name="Sarvadnya";
		bsalary=10000;
	}

	public Employee(int empid, String name, int bsalary) {
		this.empid = empid;
		this.name = name;
		this.bsalary = bsalary;
	}
	public void display() {
		System.out.println("Employee Id: "+empid+"Name: "+name+"Basic Salary: "+bsalary);
	}

}
