package EmployeeApp;

public class Manager extends Employee {
	private int petallowance;
	private int foallowance;
	private int othallowance;
	private int bsalary;
	private int totallowance;
	int gross;
	int net;
	int pf;
	
	public Manager(int empid,String name,int bsalary) {
		super(empid,name,bsalary);
		this.bsalary = bsalary;
		petallowance=(8*bsalary)/100;
		foallowance=(12*bsalary)/100;
		othallowance=(4*bsalary)/100;
		totallowance=petallowance+foallowance+othallowance;
		pf=(125*bsalary)/1000;
	}
	

	public void calculateGrossSalary() {
		
		gross=bsalary+totallowance;
		
	}
	
	public void calculateNetSalary() {
		net=gross-pf;
		
	}
	public void display() {
		System.out.println("Gross Salary:"+gross);
		System.out.println("Net Salary:"+net);
		
	}

}
