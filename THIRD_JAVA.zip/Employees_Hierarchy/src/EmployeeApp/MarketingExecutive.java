package EmployeeApp;

public class  MarketingExecutive extends Employee{
	private int ktravel;
	private int telallowance;
	private int tourallowance;
	private int bsalary;
	private int totallowance;
	int gross;
	int net;
	int pf;
	
	public MarketingExecutive(int empid,String name,int bsalary,int ktravel) {
		super(empid,name,bsalary);
		this.ktravel=ktravel;
		this.bsalary=bsalary;
		telallowance=2000;
		tourallowance=5*ktravel;
		totallowance=telallowance+tourallowance;
		pf=(125*bsalary)/1000;
	}
	
    public void calculateGrossSalary() {
		
		gross=bsalary+totallowance;
		
	}
    
    public void calculateNetSalary() {
		net=gross-pf;
    }
    
    public void display() {
    	System.out.println("Gross Salary:"+gross);
    	System.out.println("Net Salary:"+net);
    }
}
