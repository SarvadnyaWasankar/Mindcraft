import EmployeeApp.*;
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager a1=new Manager(10, "Sarvadnya", 10000);
		a1.calculateGrossSalary();
		a1.calculateNetSalary();
		a1.display();
		MarketingExecutive a2=new MarketingExecutive(11,"Charlie",10000, 10);
		a2.calculateGrossSalary();
		a2.calculateNetSalary();
		a2.display();

	}

}
