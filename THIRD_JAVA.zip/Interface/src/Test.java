interface printable{
	public void printDetails(String name, int output);
}


class CktPlayer implements printable{
	public void printDetails(String name,int output) {
		System.out.println("Name:"+name+" "+"Runs "+output);
	}
}

class Ftplayer implements printable{
	public void printDetails(String name,int output) {
		System.out.println("Name:"+name+" "+"Goals "+output);
	}
}


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CktPlayer a1=new CktPlayer();
		a1.printDetails("Sarvadnya",264);
		System.out.println();
		Ftplayer a2=new Ftplayer();
		a2.printDetails("Charlie",4);

	}

}
